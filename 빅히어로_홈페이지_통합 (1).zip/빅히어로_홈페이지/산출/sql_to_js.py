"""
팀 DB 백업(bighero_latest_*.sql) → 홈페이지용 kbo_database.js 변환 (기본 기록 + wRC+ + 수비지표)

사용법:  python3 sql_to_js.py <bighero_latest.sql> <site 폴더> [분석용 json 폴더]
  - MySQL 없이 파이썬만으로 실행 (덤프의 INSERT 문을 SQLite에 넣어서 읽음)
  - kbo_database.js : 기존 화면 코드가 그대로 쓰는 형식(필드 이름·값 형식 동일)으로 생성
  - 타자 행에 wOBA·wRC+ (batting_wrc, 강민석 계산값), 수비 기록·지표(fielding + fielding_advanced) 포함
  - 분석용 json      : lineup.py 입력 (db_batters / db_pitchers / db_profiles / db_games / db_wrc)
"""
import json, math, re, sqlite3, sys
from pathlib import Path

SQL, SITE = Path(sys.argv[1]), Path(sys.argv[2])
JSON_DIR = Path(sys.argv[3]) if len(sys.argv) > 3 else None
HERE = Path(__file__).resolve().parent

# ---------- 1. 덤프 → SQLite (메모리)
con = sqlite3.connect(":memory:")
made, counts = set(), {}
for line in open(SQL, encoding="utf-8"):
    if not line.startswith("INSERT INTO"):
        continue
    m = re.match(r"INSERT INTO `([^`]+)` \((.*?)\) VALUES ", line)
    t = m.group(1)
    if t not in made:
        con.execute(f'CREATE TABLE "{t}" ({m.group(2)})')
        made.add(t)
    con.execute(line.rstrip().rstrip(";").replace("\\'", "''"))
    counts[t] = counts.get(t, 0) + 1
print("읽은 표:", len(made), "개 |", {k: counts[k] for k in ["batting", "pitching", "players", "games", "stadiums", "batting_wrc"]})

def rows(table):
    cur = con.execute(f'SELECT * FROM "{table}"')
    cols = [d[0] for d in cur.description]
    return [{c: v for c, v in zip(cols, r) if c != "_row_id"} for r in cur.fetchall()]

def num(v):
    """'0', '13.5' 같은 글자 숫자 → 숫자, 'inf'·NaN → None"""
    if isinstance(v, str):
        s = v.strip()
        if re.fullmatch(r"-?\d+", s):
            return int(s)
        if re.fullmatch(r"-?\d*\.\d+(e-?\d+)?", s):
            v = float(s)
        elif s.lower() in ("inf", "-inf", "nan"):
            return None
        else:
            return v
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return None
        return v
    return v

def clean(r, text_cols=()):
    return {k: (v if k in text_cols else num(v)) for k, v in r.items()}

TEXT = {"선수명", "팀명", "IP", "경기일", "원정팀", "홈팀", "승리팀", "패배팀", "무승부여부", "구장", "주구장",
        "요일", "구장코드", "구장명", "경기결과구장명", "돔여부", "잔디종류", "비고", "출처", "포지션", "투타유형",
        "생년월일", "입단년도"}

def ip_decimal(ip):
    m = re.fullmatch(r"(?:(\d+))?\s*(?:(\d)/3)?", str(ip).strip())
    if not m:
        return None
    return int(m.group(1) or 0) + int(m.group(2) or 0) / 3

# ---------- 2. 표별 변환 (기존 kbo_database.js 형식에 맞춤)
batters = []
for r in rows("batting"):
    r = clean(r, TEXT)
    r["선수ID"] = int(r["선수ID"])
    so, bb = r.get("SO") or 0, r.get("BB") or 0
    r["BB_K_계산"] = bb / so if so else None
    r["ISO_계산"] = round(r["SLG"] - r["AVG"], 3) if r.get("SLG") is not None and r.get("AVG") is not None else None
    r["OPS_계산"] = round(r["OBP"] + r["SLG"], 3) if r.get("OBP") is not None and r.get("SLG") is not None else None
    batters.append(r)

# 타자 행에 wOBA·wRC+ 붙이기 (batting_wrc = 강민석 계산, 고의4구·희생플라이·시즌별 파크팩터 반영)
wrc_map = {}
for r in rows("batting_wrc"):
    w, wo = num(r.get("wRC+ (추정)")), num(r.get("wOBA (추정)"))
    if w is not None and r.get("PA"):
        wrc_map[(int(r["시즌"]), int(r["선수ID"]))] = (round(wo, 3) if wo is not None else None, int(round(w)))
for r in batters:
    wo, w = wrc_map.get((r["시즌"], r["선수ID"]), (None, None))
    r["wOBA"], r["wRC+"] = wo, w

pitchers = []
for r in rows("pitching"):
    r = clean(r, TEXT)
    r["선수ID"] = int(r["선수ID"])
    r["IP_decimal"] = ip_decimal(r["IP"])
    pitchers.append(r)

profiles = []
for r in rows("players"):
    r = clean(r, TEXT)
    r["선수ID"] = int(r["선수ID"])
    profiles.append(r)

games = []
for r in rows("games"):
    r = clean(r, TEXT)
    r["경기일"] = str(r["경기일"])[:10]          # '2024-03-23T00:00:00' → '2024-03-23'
    games.append(r)

stadiums = [clean(r, TEXT) for r in rows("stadiums")]

# 수비: 투수(P)를 뺀 모든 야수의 시즌·포지션별 기록 + 고급지표
#  - RF+ (9이닝당 아웃 관여 ÷ 같은 시즌·포지션 리그 평균 × 100) 는 이닝과 상관없이 모든 행에 계산
#  - 수비지수·범위기여·실책절감·수비기여합계·포지션순위 는 fielding_advanced 표 값 (300이닝 이상만, 나머지는 null)
FIELD_TEXT = TEXT | {"POS", "포지션코드"}
fld = [clean(r, FIELD_TEXT) for r in rows("fielding") if r["포지션코드"] != "P"]
lg = {}
for r in fld:
    k = (r["시즌"], r["포지션코드"])
    a = lg.setdefault(k, [0.0, 0.0])
    a[0] += (r["PO"] or 0) + (r["A"] or 0)
    a[1] += r["IP_decimal"] or 0
adv = {(int(r["시즌"]), int(r["선수ID"]), r["포지션코드"]): clean(r, FIELD_TEXT) for r in rows("fielding_advanced")}
fielding = []
for r in fld:
    pid = int(r["선수ID"])
    ip = r["IP_decimal"] or 0
    lg_rf9 = lg[(r["시즌"], r["포지션코드"])][0] * 9 / lg[(r["시즌"], r["포지션코드"])][1]
    rf9 = (r["PO"] + r["A"]) * 9 / ip if ip > 0 else None
    a = adv.get((r["시즌"], pid, r["포지션코드"]), {})
    att = (r["SB"] or 0) + (r["CS"] or 0)
    fielding.append({
        "시즌": r["시즌"], "선수ID": pid, "선수명": r["선수명"], "팀명": r["팀명"],
        "포지션코드": r["포지션코드"], "POS": r["POS"], "G": r["G"], "GS": r["GS"],
        "IP": r["IP"], "IP_decimal": ip, "PO": r["PO"], "A": r["A"], "E": r["E"], "DP": r["DP"], "TC": r["TC"],
        "FPCT": r.get("FPCT_계산"), "RF/9": rf9, "RF+": rf9 / lg_rf9 * 100 if rf9 is not None else None,
        "SB": r["SB"] if r["포지션코드"] == "C" else None, "CS": r["CS"] if r["포지션코드"] == "C" else None,
        "CS%": (r["CS"] / att if att else None) if r["포지션코드"] == "C" else None,
        "PB": r["PB"] if r["포지션코드"] == "C" else None,
        "분석대상": ip >= 300,
        "범위기여": a.get("범위기여"), "실책절감": a.get("실책절감"), "도루저지추가": a.get("도루저지추가"),
        "수비기여합계": a.get("수비기여합계"), "수비지수": a.get("수비지수"), "포지션순위": a.get("포지션순위"),
    })
# 확인: 직접 계산한 RF+ 가 fielding_advanced 값과 같은지
chk = [abs(f["RF+"] - adv[(f["시즌"], f["선수ID"], f["포지션코드"])]["RF+"]) for f in fielding
       if (f["시즌"], f["선수ID"], f["포지션코드"]) in adv and adv[(f["시즌"], f["선수ID"], f["포지션코드"])].get("RF+") is not None]
print("수비:", len(fielding), "행 | 수비지수 있는 행", sum(f["수비지수"] is not None for f in fielding),
      "| RF+ 검산 최대 오차", round(max(chk), 6) if chk else "-")
for f in fielding:
    for k in ("RF/9", "RF+", "CS%", "범위기여", "실책절감", "도루저지추가", "수비기여합계", "수비지수"):
        if isinstance(f[k], float):
            f[k] = round(f[k], 3)
    f["IP_decimal"] = round(f["IP_decimal"], 3)

# ---------- 3. kbo_database.js 쓰기
def dump_list(lst):
    return "[\n" + ",\n".join("    " + json.dumps(x, ensure_ascii=False) for x in lst) + "\n  ]"

adapter = (HERE / "adapter_part.js").read_text(encoding="utf-8")
src = (f"// 자동 생성: sql_to_js.py ← {SQL.name}\n"
       "// 원본: 팀 DB(bighero) batting(+batting_wrc) / pitching / players / games / stadiums / fielding(+fielding_advanced) 표\n"
       "const KBO_DATABASE = {\n"
       f'  "games": {dump_list(games)},\n'
       f'  "stadiums": {dump_list(stadiums)},\n'
       f'  "playerProfiles": {dump_list(profiles)},\n'
       f'  "batters": {dump_list(batters)},\n'
       f'  "pitchers": {dump_list(pitchers)},\n'
       f'  "fielding": {dump_list(fielding)}\n'
       "};\n\n" + adapter)
(SITE / "kbo_database.js").write_text(src, encoding="utf-8")
print("kbo_database.js:", {"games": len(games), "stadiums": len(stadiums), "playerProfiles": len(profiles),
                           "batters": len(batters), "pitchers": len(pitchers), "fielding": len(fielding)})

# ---------- 4. (wRC+ 는 batters 행 안에 포함 → 별도 wrc_plus.js 없음)
wrc = {}
for (se, pid), (wo, w) in wrc_map.items():
    wrc.setdefault(str(se), {})[str(pid)] = {"woba": wo, "wrcPlus": w}

# ---------- 5. 분석용 json (lineup.py 입력)
if JSON_DIR:
    JSON_DIR.mkdir(parents=True, exist_ok=True)
    for name, data in [("db_batters", batters), ("db_pitchers", pitchers), ("db_profiles", profiles), ("db_games", games)]:
        (JSON_DIR / f"{name}.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    wl = [{"시즌": int(s), "선수ID": int(pid), "wOBA": v["woba"], "wRC+": v["wrcPlus"]} for s, d in wrc.items() for pid, v in d.items()]
    (JSON_DIR / "db_wrc.json").write_text(json.dumps(wl, ensure_ascii=False), encoding="utf-8")
    print("분석용 json 저장:", JSON_DIR)
