"""
팀·시즌별 베스트 나인 (공격 위주 / 수비 위주) 계산 → best_lineups.js

[공통 조건] 그 시즌 해당 포지션에서 100이닝 이상 수비한 선수만 그 포지션 후보
           (수비 위주는 300이닝 이상, 해당 선수가 없는 포지션만 100이닝 이상)
[공격 위주] 8개 포지션 wRC+ 합이 최대가 되는 배치 (100타석 이상 우선, 팀 DB batting_wrc 값 사용)
           wRC+ = 구장(파크팩터)·시즌 리그 환경을 보정한 득점 생산력, 100 = 리그 평균
[수비 위주] 8개 포지션 보정 수비지수 합이 최대가 되는 배치 (이닝이 적으면 평균 50 쪽으로 보정)
[투수]     팀 선발(10경기 이상 선발) 중 FIP가 가장 낮은 투수
한 선수는 한 자리만 → 헝가리안 알고리즘(linear_sum_assignment)으로 팀 전체 합 최대화
"""
import json, sys
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

DEF_XLSX, BAT_JSON, PIT_JSON, PROF_JSON, GAMES_JSON, OUT_JS, OUT_XLSX = sys.argv[1:8]
WRC_JSON = sys.argv[8] if len(sys.argv) > 8 else None   # 팀 DB batting_wrc (sql_to_js.py 가 만든 db_wrc.json)
MIN_IP, MIN_PA, MIN_GS = 100, 100, 10
DEF_MIN_IP = 300
fallback = []
# 시즌 종료 후 팀을 떠난 선수 (방출·이적) → 최신 시즌 베스트 나인 후보에서 제외. (팀, 선수명) 형식으로 추가
DEPARTED = [("KIA", "데일"), ("KIA", "아데를린"), ("두산", "카메론")]
POS = ["C", "1B", "2B", "3B", "SS", "LF", "CF", "RF"]
POS_KR = {"C": "포수", "1B": "1루수", "2B": "2루수", "3B": "3루수", "SS": "유격수", "LF": "좌익수", "CF": "중견수", "RF": "우익수"}
INFIELD = ["1B", "2B", "3B", "SS"]

d = pd.read_excel(DEF_XLSX)
bat = pd.read_json(BAT_JSON); pit = pd.read_json(PIT_JSON); prof = pd.read_json(PROF_JSON)
f = d[d["포지션코드"] != "P"].copy()

# ---------- 수비지수 (수비 고급지표와 같은 공식, 대상만 100이닝 이상으로 확대)
S = ["IP_decimal", "PO", "A", "E", "DP", "TC", "SB", "CS", "PB"]
lg = f.groupby(["시즌", "포지션코드"])[S].sum()
lg["lg_RF9"] = (lg.PO + lg.A) * 9 / lg.IP_decimal
lg["lg_er"] = lg.E / lg.TC
lg["lg_DP9"] = lg.DP * 9 / lg.IP_decimal
lg["lg_A9"] = lg.A * 9 / lg.IP_decimal
lg["lg_att9"] = (lg.SB + lg.CS) * 9 / lg.IP_decimal
lg["lg_PB9"] = lg.PB * 9 / lg.IP_decimal
lg = lg[["lg_RF9", "lg_er", "lg_DP9", "lg_A9", "lg_att9", "lg_PB9"]].reset_index()
q = f[f.IP_decimal >= MIN_IP].merge(lg, on=["시즌", "포지션코드"])
ip = q.IP_decimal
q["RF+"] = (q.PO + q.A) * 9 / ip / q.lg_RF9 * 100
q["실책절감9"] = (q.lg_er * q.TC - q.E) * 9 / ip
q["DP+"] = (q.DP * 9 / ip) / q.lg_DP9 * 100
q["보살+"] = (q.A * 9 / ip) / q.lg_A9 * 100
att = q.SB + q.CS
q["도루저지율"] = np.where(att > 0, q.CS / att.replace(0, np.nan), np.nan)
q["도루억제9"] = q.lg_att9 - att * 9 / ip
q["포일절감9"] = q.lg_PB9 - q.PB * 9 / ip

def z(s):
    sd = s.std(ddof=0)
    return (s - s.mean()) / sd if sd > 0 else s * 0

parts = []
for (season, pos), g in q.groupby(["시즌", "포지션코드"]):
    g = g.copy()
    if pos == "C":
        comp = 0.4 * z(g["도루저지율"].fillna(g["도루저지율"].mean())) + 0.2 * z(g["도루억제9"]) + 0.2 * z(g["포일절감9"]) + 0.2 * z(g["실책절감9"])
    else:
        sp = g["DP+"] if pos in INFIELD else g["보살+"]
        comp = 0.6 * z(g["RF+"]) + 0.3 * z(g["실책절감9"]) + 0.1 * z(sp.fillna(100))   # 야수 비율 범위 0.6 · 실책 0.3 · 병살/보살 0.1 (sb2.py와 동일)
    g["수비지수"] = 50 + 10 * z(comp)
    parts.append(g)
q = pd.concat(parts)
# 소표본 보정: 이닝이 적을수록 평균(50) 쪽으로 당김 (300이닝이면 절반만 반영, 900이닝이면 75% 반영)
SHRINK_K = 300
q["보정수비지수"] = 50 + (q["수비지수"] - 50) * q["IP_decimal"] / (q["IP_decimal"] + SHRINK_K)

# ---------- 파크팩터 (경기 결과로 계산: 홈구장 경기당 총득점 / 같은 팀 원정 경기당 총득점, 3시즌 합산)
games = pd.read_json(GAMES_JSON)
home_main = (games.groupby(["시즌", "홈팀"])["구장"].agg(lambda x: x.value_counts().index[0])
             .rename("주구장").reset_index().rename(columns={"홈팀": "팀"}))
pf = {}
for stad, ten in home_main.groupby("주구장"):
    pairs = set(zip(ten["시즌"], ten["팀"]))
    hm = games[np.array([(a, b) in pairs for a, b in zip(games["시즌"], games["홈팀"])]) & (games["구장"] == stad)]
    rd = games[np.array([(a, b) in pairs for a, b in zip(games["시즌"], games["원정팀"])]) & (games["구장"] != stad)]
    pf[stad] = hm["총득점"].mean() / rd["총득점"].mean()
home_main["PF"] = home_main["주구장"].map(pf)
home_main["PF_half"] = (1 + home_main["PF"]) / 2          # 홈경기는 절반이므로 반만 반영
print("파크팩터:", {k: round(v, 3) for k, v in sorted(pf.items(), key=lambda x: -x[1])})

# ---------- wOBA → wRAA → wRC+ (선형가중치는 표준 wOBA 계수, 시즌 리그 OBP 수준에 맞춰 스케일)
W = {"BB": 0.69, "HBP": 0.72, "1B": 0.89, "2B": 1.27, "3B": 1.62, "HR": 2.10}
bat["1B"] = bat["H"] - bat["2B"] - bat["3B"] - bat["HR"]
bat["den"] = bat["AB"] + bat["BB"] + bat["HBP"]
bat["raw"] = sum(W[k] * bat[k] for k in W)
lgb = bat.groupby("시즌")[["raw", "den", "H", "BB", "HBP", "R", "PA"]].sum()
lgb["lgwOBA_raw"] = lgb.raw / lgb.den
lgb["lgOBP"] = (lgb.H + lgb.BB + lgb.HBP) / lgb.den
lgb["scale"] = lgb.lgOBP / lgb.lgwOBA_raw              # 리그 wOBA = 리그 OBP 가 되도록
lgb["lgRPA"] = lgb.R / lgb.PA
bat = bat.merge(lgb[["scale", "lgOBP", "lgRPA"]].reset_index(), on="시즌")
bat["wOBA"] = bat.raw / bat.den.replace(0, np.nan) * bat.scale
bat["wRAA"] = (bat.wOBA - bat.lgOBP) / bat.scale * bat.PA
bat = bat.merge(home_main[["시즌", "팀", "PF_half"]], left_on=["시즌", "팀명"], right_on=["시즌", "팀"], how="left")
bat["wRC+"] = ((bat.wRAA / bat.PA + bat.lgRPA) + (bat.lgRPA - bat.PF_half.fillna(1) * bat.lgRPA)) / bat.lgRPA * 100
# 팀 DB의 wRC+(강민석 계산: 고의4구·희생플라이·시즌별 파크팩터 반영)가 있으면 그 값을 사용 → 홈페이지·보고서 수치 통일
if WRC_JSON:
    tw = pd.read_json(WRC_JSON).rename(columns={"wOBA": "wOBA_팀", "wRC+": "wRC+_팀"})
    bat = bat.merge(tw, on=["시즌", "선수ID"], how="left")
    print("팀 wRC+ 사용:", bat["wRC+_팀"].notna().sum(), "명 / 자체 계산과 상관",
          round(bat.loc[bat.PA >= 100, "wRC+"].corr(bat.loc[bat.PA >= 100, "wRC+_팀"]), 3))
    bat["wRC+"] = bat["wRC+_팀"].fillna(bat["wRC+"])
    bat["wOBA"] = bat["wOBA_팀"].fillna(bat["wOBA"])
chk = bat[bat.PA >= 100]
print("wRC+ 검증(100타석↑ PA가중 평균 ≈100):", round(np.average(chk["wRC+"], weights=chk.PA), 1),
      "| 2026 상위:", chk[chk.시즌 == chk.시즌.max()].nlargest(5, "wRC+")[["선수명", "팀명", "OPS", "wRC+"]].round(3).values.tolist())

# ---------- 팀별 wRC+ 순위 (100타석↑, 메인 화면 자동 순환용)
wrc_rank = {}
for (se, tm), g in bat[bat.PA >= MIN_PA].groupby(["시즌", "팀명"]):
    g = g.sort_values("wRC+", ascending=False)
    wrc_rank[(se, tm)] = [{"id": int(r.선수ID), "name": r.선수명, "wrcPlus": int(round(r["wRC+"])), "pa": int(r.PA)} for _, r in g.iterrows()]

# ---------- 타격 정보 결합
bat = bat.rename(columns={"팀명": "타격팀"})
q = q.merge(bat[["시즌", "선수ID", "PA", "AVG", "HR", "RBI", "OPS", "wOBA", "wRC+"]], on=["시즌", "선수ID"], how="left")
num = prof.set_index("선수ID")["등번호"].to_dict()

# ---------- FIP (투수)
pit["IP"] = pit["IP_decimal"]
lgp = pit.groupby("시즌")[["ER", "IP", "HR", "BB", "HBP", "SO"]].sum()
lgp["C"] = lgp.ER * 9 / lgp.IP - (13 * lgp.HR + 3 * (lgp.BB + lgp.HBP) - 2 * lgp.SO) / lgp.IP
pit = pit.merge(lgp["C"].reset_index(), on="시즌")
pit["FIP"] = (13 * pit.HR + 3 * (pit.BB + pit.HBP) - 2 * pit.SO) / pit.IP + pit.C

def assign(cands, score_col, tie_col):
    """cands: 후보 행(선수×포지션). 팀 전체 점수 합이 최대가 되도록 8개 포지션 배치."""
    players = sorted(cands["선수ID"].unique())
    BIG = -1e6
    M = np.full((len(players), len(POS)), BIG)
    for _, r in cands.iterrows():
        i, j = players.index(r["선수ID"]), POS.index(r["포지션코드"])
        s = r[score_col] + 1e-4 * (0 if pd.isna(r[tie_col]) else r[tie_col])   # 동점 처리용 아주 작은 가중치
        M[i, j] = max(M[i, j], s)
    ri, ci = linear_sum_assignment(-M)
    out = {}
    for i, j in zip(ri, ci):
        if M[i, j] <= BIG / 2: continue
        row = cands[(cands["선수ID"] == players[i]) & (cands["포지션코드"] == POS[j])].iloc[0]
        out[POS[j]] = row
    return out

def card(row, pos):
    def f3(v): return None if pd.isna(v) else round(float(v), 3)
    return {"pos": pos, "posKr": POS_KR[pos], "id": int(row["선수ID"]), "name": row["선수명"],
            "num": f"#{int(num[row['선수ID']])}" if pd.notna(num.get(row["선수ID"])) else "#00",
            "ip": round(float(row["IP_decimal"]), 1), "pa": None if pd.isna(row["PA"]) else int(row["PA"]),
            "avg": f3(row["AVG"]), "hr": None if pd.isna(row["HR"]) else int(row["HR"]),
            "rbi": None if pd.isna(row["RBI"]) else int(row["RBI"]), "ops": f3(row["OPS"]),
            "woba": f3(row["wOBA"]), "wrcPlus": None if pd.isna(row["wRC+"]) else int(round(float(row["wRC+"]))),
            "defIdx": round(float(row["수비지수"]), 1), "defAdj": round(float(row["보정수비지수"]), 1)}

result, rows = {}, []
for season in sorted(q["시즌"].unique()):
    result[str(season)] = {}
    for team in sorted(q["팀명"].unique()):
        c = q[(q["시즌"] == season) & (q["팀명"] == team)].copy()
        if season == q["시즌"].max():
            gone = [n for t_, n in DEPARTED if t_ == team]
            c = c[~c["선수명"].isin(gone)]
        # 공격 위주: 100타석 이상 선수를 우선(못 채우면 전체 후보 사용)
        off_c = c[c["PA"].fillna(0) >= MIN_PA].copy()
        off_c["OFF_score"] = off_c["wRC+"].fillna(0)
        off = assign(off_c, "OFF_score", "수비지수")
        if len(off) < 8:
            c2 = c.copy(); c2["OFF_score"] = c2["wRC+"].fillna(0) - np.where(c2["PA"].fillna(0) >= MIN_PA, 0, 1000)
            off = assign(c2, "OFF_score", "수비지수")
        # 수비 위주: 수비 분석과 같은 300이닝 기준. 300이닝 선수가 없는 포지션만 100이닝 이상으로 확대
        # 300이닝 미만 후보는 큰 감점(-100)을 줘서, 300이닝 선수로 8자리를 못 채울 때만 들어가게 함
        dc = c.copy()
        dc["DEF_score"] = dc["보정수비지수"] - np.where(dc["IP_decimal"] >= DEF_MIN_IP, 0, 100)
        dfn = assign(dc, "DEF_score", "wRC+")
        low = [p_ for p_, r_ in dfn.items() if r_["IP_decimal"] < DEF_MIN_IP]
        if low: fallback.append((int(season), team, low))
        tp = pit[(pit["시즌"] == season) & (pit["팀명"] == team) & (pit["GS"] >= MIN_GS)]
        if season == q["시즌"].max():
            tp = tp[~tp["선수명"].isin([n for t_, n in DEPARTED if t_ == team])]
        ace = tp.nsmallest(1, "FIP").iloc[0]
        pcard = {"pos": "P", "posKr": "투수", "id": int(ace["선수ID"]), "name": ace["선수명"],
                 "num": f"#{int(num[ace['선수ID']])}" if pd.notna(num.get(ace["선수ID"])) else "#00",
                 "era": round(float(ace["ERA"]), 2), "fip": round(float(ace["FIP"]), 2), "ip": ace["IP_decimal"].round(1), "gs": int(ace["GS"])}
        entry = {"pitcher": pcard}
        entry["wrcRank"] = [x for x in wrc_rank.get((season, team), [])
                            if not (season == q["시즌"].max() and (team, x["name"]) in DEPARTED)]
        for mode, lu in [("offense", off), ("defense", dfn)]:
            entry[mode] = [card(lu[p], p) for p in POS if p in lu]
            for p in POS:
                if p in lu:
                    r = lu[p]
                    rows.append({"시즌": season, "팀": team, "구분": "공격 위주" if mode == "offense" else "수비 위주", "포지션": POS_KR[p],
                                 "선수": r["선수명"], "수비이닝": round(r["IP_decimal"], 1), "타석": r["PA"], "OPS": r["OPS"], "wRC+": None if pd.isna(r["wRC+"]) else round(r["wRC+"]), "수비지수": round(r["수비지수"], 1), "보정수비지수": round(r["보정수비지수"], 1)})
            rows.append({"시즌": season, "팀": team, "구분": "공격 위주" if mode == "offense" else "수비 위주", "포지션": "투수",
                         "선수": ace["선수명"], "수비이닝": round(ace["IP_decimal"], 1), "타석": None, "OPS": None, "수비지수": None})
        entry["offenseWrcAvg"] = round(np.mean([x["wrcPlus"] or 0 for x in entry["offense"]]))
        entry["offenseOpsAvg"] = round(np.mean([x["ops"] or 0 for x in entry["offense"]]), 3)
        entry["defenseIdxAvg"] = round(np.mean([x["defAdj"] for x in entry["defense"]]), 1)
        result[str(season)][team] = entry

js = ("// 자동 생성: lineup.py — 팀·시즌별 베스트 나인 (공격 위주 / 수비 위주)\n"
      "// 조건: 해당 포지션 시즌 100이닝 이상 수비(수비 위주는 300이닝 이상) / 공격 위주 = wRC+ 합 최대(파크팩터 보정), 수비 위주 = 보정 수비지수 합 최대(이닝 적으면 평균 쪽으로 보정) / 투수 = 팀 선발 중 FIP 최저\n"
      "const BEST_LINEUPS = " + json.dumps(result, ensure_ascii=False, default=float) + ";\n")
open(OUT_JS, "w", encoding="utf-8").write(js)

pd.DataFrame(rows).to_excel(OUT_XLSX, index=False)
print("teams x seasons:", sum(len(v) for v in result.values()), "| 300이닝 미충족으로 100이닝 확대:", fallback)
for t in ["LG", "KIA", "한화"]:
    e = result["2026"][t]
    print(t, "공격:", [(x["posKr"], x["name"], x["wrcPlus"], x["ops"]) for x in e["offense"]])
    print(t, "수비:", [(x["posKr"], x["name"], x["defIdx"], x["ip"]) for x in e["defense"]], "| P", e["pitcher"]["name"], e["pitcher"]["fip"])
