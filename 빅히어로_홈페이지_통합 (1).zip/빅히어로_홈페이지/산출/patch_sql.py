"""수비지수 비율 변경(0.6/0.3/0.1) 결과를 팀 DB 백업에 반영
사용법: python3 patch_sql.py <원본 bighero_latest.sql> <수비_고급지표.xlsx> <수비_상위지표.xlsx> <새 전체 덤프.sql> <패치만.sql>
 - fielding_advanced ← 수비_고급지표.xlsx '시즌별_고급지표'
 - fielding_ranking  ← 수비_상위지표.xlsx '종합순위_3시즌'
 - fielding_growth   ← 수비_상위지표.xlsx '선수별_시즌수비지수'
"""
import sys, re, math
import pandas as pd
SRC, ADV, TOP, OUT_FULL, OUT_PATCH = sys.argv[1:6]
TABLES = {
    "fielding_advanced": pd.read_excel(ADV, sheet_name="시즌별_고급지표"),
    "fielding_ranking": pd.read_excel(TOP, sheet_name="종합순위_3시즌"),
    "fielding_growth": pd.read_excel(TOP, sheet_name="선수별_시즌수비지수"),
}
# 원본 덤프의 열 순서·형식(선수ID는 문자열) 그대로 맞춤
cols = {}
for line in open(SRC, encoding="utf-8"):
    m = re.match(r"INSERT INTO `([^`]+)` \((.*?)\) VALUES ", line)
    if m and m.group(1) in TABLES and m.group(1) not in cols:
        cols[m.group(1)] = [c.strip().strip("`") for c in m.group(2).split(",")]
TEXT = {"선수ID", "포지션코드", "POS", "선수명", "팀명", "최근팀", "포지션_2026_한글", "유형", "포지션_2024", "포지션_2025", "포지션_2026"}
def lit(v, col):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "NULL"
    if col in TEXT:
        return "'" + str(int(v) if isinstance(v, float) and v.is_integer() else v).replace("'", "''") + "'"
    if isinstance(v, float) and v.is_integer() and col in ("시즌", "순위", "포지션순위", "PO", "A", "E", "DP"):
        return str(int(v))
    return repr(float(v)) if isinstance(v, float) else str(v)
def inserts(t):
    df = TABLES[t]; cs = cols[t]
    miss = [c for c in cs if c != "_row_id" and c not in df.columns]
    assert not miss, (t, miss)
    head = f"INSERT INTO `{t}` (" + ", ".join(f"`{c}`" for c in cs) + ") VALUES ("
    out = []
    for i, r in enumerate(df.itertuples(index=False), 1):
        row = dict(zip(df.columns, r))
        vals = [str(i) if c == "_row_id" else lit(row[c], c) for c in cs]
        out.append(head + ",".join(vals) + ");\n")
    return out
done = set(); n_old = {t: 0 for t in TABLES}
with open(OUT_FULL, "w", encoding="utf-8") as w:
    for line in open(SRC, encoding="utf-8"):
        m = re.match(r"INSERT INTO `([^`]+)` ", line)
        if m and m.group(1) in TABLES:
            t = m.group(1); n_old[t] += 1
            if t not in done:
                w.writelines(inserts(t)); done.add(t)
            continue
        w.write(line)
with open(OUT_PATCH, "w", encoding="utf-8") as w:
    w.write("-- 수비지수 비율 변경 (야수: 범위 0.6 · 실책 0.3 · 병살/보살 0.1) 반영 패치\n-- 기존 DB에서 실행: USE bighero; 후 이 파일 실행\nSET NAMES utf8mb4;\nSTART TRANSACTION;\n")
    for t in TABLES:
        w.write(f"DELETE FROM `{t}`;\n"); w.writelines(inserts(t))
    w.write("COMMIT;\n")
print({t: (n_old[t], len(TABLES[t])) for t in TABLES})
