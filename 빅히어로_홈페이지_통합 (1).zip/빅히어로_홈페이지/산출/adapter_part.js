// BIGHERO 화면용 데이터 어댑터: 원본 정규화 데이터를 기존 화면 구조로 변환
const kboCompleteDatabase = (() => {
  const raw = KBO_DATABASE;
  const teams = {
    KIA: { fullName: 'KIA 타이거즈', badge: 'KIA', color: 'bg-red-700', stadium: '광주기아챔피언스필드' },
    삼성: { fullName: '삼성 라이온즈', badge: '삼성', color: 'bg-blue-700', stadium: '대구삼성라이온즈파크' },
    LG: { fullName: 'LG 트윈스', badge: 'LG', color: 'bg-red-600', stadium: '잠실야구장' },
    두산: { fullName: '두산 베어스', badge: '두산', color: 'bg-blue-900', stadium: '잠실야구장' },
    KT: { fullName: 'KT 위즈', badge: 'KT', color: 'bg-black', stadium: '수원KT위즈파크' },
    SSG: { fullName: 'SSG 랜더스', badge: 'SSG', color: 'bg-red-800', stadium: '인천SSG랜더스필드' },
    롯데: { fullName: '롯데 자이언츠', badge: '롯데', color: 'bg-blue-800', stadium: '사직야구장' },
    한화: { fullName: '한화 이글스', badge: '한화', color: 'bg-orange-600', stadium: '대전한화생명볼파크' },
    NC: { fullName: 'NC 다이노스', badge: 'NC', color: 'bg-sky-800', stadium: '창원NC파크' },
    키움: { fullName: '키움 히어로즈', badge: '키움', color: 'bg-burgundy-700', stadium: '고척스카이돔' }
  };
  const profiles = new Map((raw.playerProfiles || []).map(p => [String(p.선수ID), p]));
  // 수비: 시즌|선수ID → 포지션별 기록 (이닝 많은 순). 주포지션 = 가장 많이 뛴 포지션
  const fieldMap = new Map();
  (raw.fielding || []).forEach(f => {
    const k = `${f.시즌}|${f.선수ID}`;
    if (!fieldMap.has(k)) fieldMap.set(k, []);
    fieldMap.get(k).push(f);
  });
  fieldMap.forEach(list => list.sort((a, b) => (b.IP_decimal || 0) - (a.IP_decimal || 0)));
  const seasons = [...new Set([...(raw.batters || []).map(x => String(x.시즌)), ...(raw.pitchers || []).map(x => String(x.시즌))])].sort();
  const out = {};
  for (const season of seasons) {
    out[season] = {};
    for (const [teamKey, meta] of Object.entries(teams)) {
      const profileFor = row => profiles.get(String(row.선수ID)) || {};
      const hitters = (raw.batters || []).filter(x => String(x.시즌) === season && x.팀명 === teamKey).map(x => {
        const p = profileFor(x);
        return { ...x, name: x.선수명, teamName: teamKey, pos: p.포지션 || '야수', num: p.등번호 != null ? `#${p.등번호}` : '#00', avg: Number(x.AVG || 0).toFixed(3).replace(/^0/, ''), h: x.H ?? 0, hr: x.HR ?? 0, rbi: x.RBI ?? 0, ops: Number(x.OPS || 0).toFixed(3), wrcPlus: x['wRC+'] ?? null, woba: x.wOBA ?? null, defense: fieldMap.get(`${x.시즌}|${x.선수ID}`) || [], mainPos: (fieldMap.get(`${x.시즌}|${x.선수ID}`) || [])[0] || null, defIdx: ((fieldMap.get(`${x.시즌}|${x.선수ID}`) || [])[0] || {}).수비지수 ?? null, birth: p.생년월일 || '정보 없음', ht: p['신장(cm)'] ? `${p['신장(cm)']}cm` : '-' };
      }).filter(h => h.pos !== '투수' && Number(h.PA || 0) > 0); // 투수·타석 0인 선수는 타자 목록에서 제외
      const pitchers = (raw.pitchers || []).filter(x => String(x.시즌) === season && x.팀명 === teamKey).map(x => {
        const p = profileFor(x);
        return { ...x, name: x.선수명, teamName: teamKey, pos: x.GS > 0 ? 'SP' : 'RP', num: p.등번호 != null ? `#${p.등번호}` : '#00', era: x.ERA ?? 0, w: x.W ?? 0, l: x.L ?? 0, so: x.SO ?? 0, ip: x.IP ?? '0', whip: x.WHIP ?? 0, birth: p.생년월일 || '정보 없음', ht: p['신장(cm)'] ? `${p['신장(cm)']}cm` : '-' };
      });
      out[season][teamKey] = { ...meta, hitters, pitchers };
    }
  }
  return out;
})();
