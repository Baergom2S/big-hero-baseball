// 기록실 표 정렬: 머리글 1번 클릭 = 낮은 순(▲), 다시 클릭 = 높은 순(▼)
const TableSort = {
  key: null,
  dir: 1,
  theadSel: null,

  init(theadSel, render) {
    this.theadSel = theadSel;
    document.querySelectorAll(theadSel + ' th[data-sort]').forEach(th => {
      th.classList.add('cursor-pointer', 'select-none', 'hover:text-emerald-700');
      th.title = '클릭: 낮은 순 / 한 번 더: 높은 순';
      th.addEventListener('click', () => {
        const k = th.dataset.sort;
        if (this.key === k) this.dir *= -1;
        else {
          this.key = k;
          this.dir = 1;
        }
        render();
      });
    });
  },

  value(v) {
    if (v === null || v === undefined || v === '' || v === '-') return null;
    if (typeof v === 'number') return isNaN(v) ? null : v;
    const s = String(v);
    if (!/\d/.test(s)) return s;
    const n = Number(s.replace(/[^0-9.\-]/g, ''));
    return isNaN(n) ? s : n;
  },

  apply(arr) {
    if (!this.key) return arr;
    return arr.slice().sort((a, b) => {
      const av = this.value(a[this.key]);
      const bv = this.value(b[this.key]);
      if (av === null && bv === null) return 0;
      if (av === null) return 1;
      if (bv === null) return -1;
      const cmp = typeof av === 'number' && typeof bv === 'number'
        ? av - bv
        : String(av).localeCompare(String(bv), 'ko');
      return cmp * this.dir;
    });
  },

  mark() {
    if (!this.theadSel) return;
    document.querySelectorAll(this.theadSel + ' th[data-sort]').forEach(th => {
      const k = th.dataset.sort;
      th.innerText = th.innerText.replace(/[▲▼]/g, '').trim();
      if (k === this.key) {
        th.classList.add('text-emerald-700', 'font-bold');
        th.innerText += this.dir === 1 ? ' ▲' : ' ▼';
      } else {
        th.classList.remove('text-emerald-700', 'font-bold');
      }
    });
  }
};
