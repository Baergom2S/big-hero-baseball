const selectedLeague = new URLSearchParams(location.search).get('league') === 'futures' ? 'futures' : 'first';
const leagueDatabase = selectedLeague === 'futures'
  ? buildKboDatabase(KBO_FUTURES_DATABASE, true)
  : kboCompleteDatabase;

function syncLeagueLinks() {
  for (const link of document.querySelectorAll('a[href="hitters.html"], a[href="pitchers.html"]')) {
    if (selectedLeague === 'futures') link.href += '?league=futures';
  }
}

function initLeagueFilters() {
  const params = new URLSearchParams(location.search);
  const league = document.getElementById('league-filter');
  const season = document.getElementById('season-filter');
  const team = document.getElementById('team-filter');
  league.value = selectedLeague;
  const seasons = Object.keys(leagueDatabase).sort();
  season.replaceChildren(...seasons.map(year => new Option(year + ' 시즌', year)));
  const requested = params.get('season');
  season.value = seasons.includes(requested) ? requested : seasons.at(-1);
  const updateTeams = () => {
    const previous = team.value;
    const entries = Object.entries(leagueDatabase[season.value]);
    const recordType = location.pathname.endsWith('pitchers.html') ? 'pitchers' : 'hitters';
    team.replaceChildren(new Option('전체 구단', 'ALL'), ...entries
      .filter(([, meta]) => selectedLeague === 'first' || meta[recordType].length)
      .map(([key, meta]) => new Option(meta.fullName, key)));
    if (Array.from(team.options).some(option => option.value === previous)) team.value = previous;
  };
  season.addEventListener('change', updateTeams, true);
  updateTeams();
  league.addEventListener('change', () => {
    const url = new URL(location.href);
    url.searchParams.set('league', league.value);
    url.searchParams.set('season', season.value);
    location.href = url.href;
  });
  syncLeagueLinks();
}
