/* BIGHERO 6각형 지표 공통 모듈 (결측값 대응 및 비교 다각형 강제 렌더링 지원) */
const SIX_AXIS_PITCHER_ADVANCED = [{"season":"2024","playerId":64001,"fip":3.637,"kbb":14.3},{"season":"2024","playerId":72523,"fip":6.323,"kbb":7.3},{"season":"2024","playerId":53609,"fip":4.316,"kbb":12.5},{"season":"2024","playerId":68220,"fip":4.17,"kbb":10.9},{"season":"2024","playerId":63543,"fip":4.97,"kbb":10.0},{"season":"2024","playerId":77263,"fip":4.068,"kbb":6.4},{"season":"2024","playerId":65522,"fip":5.068,"kbb":5.7},{"season":"2024","playerId":76225,"fip":5.813,"kbb":3.6},{"season":"2024","playerId":77829,"fip":5.153,"kbb":11.6},{"season":"2024","playerId":51713,"fip":5.229,"kbb":4.8},{"season":"2024","playerId":51715,"fip":5.805,"kbb":4.2},{"season":"2024","playerId":61365,"fip":4.735,"kbb":10.2},{"season":"2024","playerId":60337,"fip":5.367,"kbb":11.5},{"season":"2024","playerId":66145,"fip":5.915,"kbb":7.7},{"season":"2024","playerId":69745,"fip":5.273,"kbb":8.1},{"season":"2024","playerId":50393,"fip":4.715,"kbb":8.9},{"season":"2024","playerId":51230,"fip":5.347,"kbb":5.7},{"season":"2024","playerId":50360,"fip":8.567,"kbb":-1.0},{"season":"2024","playerId":67246,"fip":6.258,"kbb":10.1},{"season":"2024","playerId":68043,"fip":3.545,"kbb":15.8},{"season":"2024","playerId":68200,"fip":7.007,"kbb":0.0},{"season":"2024","playerId":65048,"fip":4.302,"kbb":12.3},{"season":"2024","playerId":65769,"fip":7.775,"kbb":12.1},{"season":"2024","playerId":63894,"fip":4.876,"kbb":6.4},{"season":"2024","playerId":53754,"fip":4.261,"kbb":6.2},{"season":"2024","playerId":66018,"fip":6.15,"kbb":3.9},{"season":"2024","playerId":67828,"fip":4.804,"kbb":9.0},{"season":"2024","playerId":68928,"fip":4.889,"kbb":3.1},{"season":"2024","playerId":54368,"fip":6.623,"kbb":1.4},{"season":"2024","playerId":68900,"fip":3.424,"kbb":18.6},{"season":"2024","playerId":62528,"fip":3.545,"kbb":15.9},{"season":"2024","playerId":53262,"fip":5.08,"kbb":3.6},{"season":"2024","playerId":64596,"fip":3.729,"kbb":12.3},{"season":"2024","playerId":54319,"fip":5.067,"kbb":2.2},{"season":"2024","playerId":69367,"fip":6.529,"kbb":-1.3},{"season":"2024","playerId":64580,"fip":3.629,"kbb":14.4},{"season":"2024","playerId":67391,"fip":4.701,"kbb":7.5},{"season":"2024","playerId":65062,"fip":5.656,"kbb":10.9},{"season":"2024","playerId":75867,"fip":5.137,"kbb":13.9},{"season":"2024","playerId":51516,"fip":5.293,"kbb":11.1},{"season":"2024","playerId":76430,"fip":4.23,"kbb":9.9},{"season":"2024","playerId":62360,"fip":5.024,"kbb":8.4},{"season":"2024","playerId":54263,"fip":3.256,"kbb":17.3},{"season":"2024","playerId":67539,"fip":6.468,"kbb":7.1},{"season":"2024","playerId":54640,"fip":3.68,"kbb":16.0},{"season":"2024","playerId":73211,"fip":4.691,"kbb":12.3},{"season":"2024","playerId":54804,"fip":4.966,"kbb":6.9},{"season":"2024","playerId":54666,"fip":3.975,"kbb":16.7},{"season":"2024","playerId":54443,"fip":4.228,"kbb":13.6},{"season":"2024","playerId":65949,"fip":4.655,"kbb":9.3},{"season":"2024","playerId":76715,"fip":3.649,"kbb":15.0},{"season":"2024","playerId":52701,"fip":4.702,"kbb":11.8},{"season":"2024","playerId":60336,"fip":5.2,"kbb":3.2},{"season":"2024","playerId":62869,"fip":5.187,"kbb":12.1},{"season":"2024","playerId":54720,"fip":3.881,"kbb":16.0},{"season":"2024","playerId":53139,"fip":7.516,"kbb":0.8},{"season":"2024","playerId":64893,"fip":6.157,"kbb":4.1},{"season":"2024","playerId":67703,"fip":3.432,"kbb":15.5},{"season":"2024","playerId":64021,"fip":4.391,"kbb":9.0},{"season":"2024","playerId":60559,"fip":4.753,"kbb":15.5},{"season":"2024","playerId":52060,"fip":4.235,"kbb":21.6},{"season":"2024","playerId":65639,"fip":4.496,"kbb":7.3},{"season":"2024","playerId":60841,"fip":6.83,"kbb":7.9},{"season":"2024","playerId":69594,"fip":4.112,"kbb":11.2},{"season":"2024","playerId":67266,"fip":6.083,"kbb":8.1},{"season":"2024","playerId":52528,"fip":3.985,"kbb":20.0},{"season":"2024","playerId":54243,"fip":3.529,"kbb":16.4},{"season":"2024","playerId":65109,"fip":6.574,"kbb":-4.4},{"season":"2024","playerId":77446,"fip":5.441,"kbb":8.3},{"season":"2024","playerId":52043,"fip":5.036,"kbb":17.2},{"season":"2024","playerId":52257,"fip":2.807,"kbb":20.3},{"season":"2024","playerId":53714,"fip":3.762,"kbb":14.7},{"season":"2024","playerId":61895,"fip":4.985,"kbb":6.6},{"season":"2024","playerId":50109,"fip":4.624,"kbb":3.8},{"season":"2024","playerId":69041,"fip":5.123,"kbb":4.2},{"season":"2024","playerId":67143,"fip":4.454,"kbb":9.1},{"season":"2024","playerId":69962,"fip":4.913,"kbb":8.7},{"season":"2024","playerId":53898,"fip":5.217,"kbb":3.5},{"season":"2024","playerId":54843,"fip":5.326,"kbb":4.9},{"season":"2024","playerId":68902,"fip":5.183,"kbb":11.1},{"season":"2024","playerId":54664,"fip":3.801,"kbb":19.0},{"season":"2024","playerId":69045,"fip":5.77,"kbb":4.4},{"season":"2024","playerId":54833,"fip":3.773,"kbb":21.2},{"season":"2024","playerId":77637,"fip":4.597,"kbb":12.1},{"season":"2024","playerId":65056,"fip":4.753,"kbb":17.3},{"season":"2024","playerId":54119,"fip":3.878,"kbb":20.0},{"season":"2024","playerId":54134,"fip":4.057,"kbb":15.0},{"season":"2024","playerId":53825,"fip":4.245,"kbb":14.1},{"season":"2024","playerId":75421,"fip":5.269,"kbb":10.3},{"season":"2024","playerId":50859,"fip":5.561,"kbb":8.7},{"season":"2024","playerId":54755,"fip":3.73,"kbb":18.0},{"season":"2024","playerId":69343,"fip":5.39,"kbb":6.3},{"season":"2024","playerId":73117,"fip":2.464,"kbb":20.4},{"season":"2024","playerId":54063,"fip":4.59,"kbb":8.6},{"season":"2024","playerId":69446,"fip":4.482,"kbb":11.6},{"season":"2024","playerId":53546,"fip":3.621,"kbb":17.2},{"season":"2024","playerId":50106,"fip":3.09,"kbb":17.5},{"season":"2024","playerId":54064,"fip":6.149,"kbb":1.0},{"season":"2024","playerId":53613,"fip":5.156,"kbb":4.1},{"season":"2024","playerId":69205,"fip":6.347,"kbb":6.0},{"season":"2024","playerId":53892,"fip":5.401,"kbb":0.7},{"season":"2024","playerId":52530,"fip":6.267,"kbb":-3.3},{"season":"2024","playerId":65616,"fip":4.396,"kbb":11.1},{"season":"2024","playerId":52204,"fip":4.192,"kbb":8.4},{"season":"2024","playerId":65117,"fip":5.437,"kbb":8.7},{"season":"2024","playerId":69054,"fip":4.531,"kbb":11.2},{"season":"2024","playerId":63960,"fip":4.753,"kbb":5.0},{"season":"2024","playerId":50464,"fip":8.398,"kbb":-1.3},{"season":"2024","playerId":60146,"fip":4.582,"kbb":10.6},{"season":"2024","playerId":51454,"fip":4.946,"kbb":8.1},{"season":"2024","playerId":66291,"fip":4.376,"kbb":8.1},{"season":"2024","playerId":51948,"fip":5.41,"kbb":7.6},{"season":"2024","playerId":77211,"fip":4.533,"kbb":11.1},{"season":"2024","playerId":61145,"fip":5.38,"kbb":0.6},{"season":"2024","playerId":64565,"fip":7.869,"kbb":4.4},{"season":"2024","playerId":60263,"fip":5.268,"kbb":11.9},{"season":"2024","playerId":50354,"fip":7.122,"kbb":0.5},{"season":"2024","playerId":50904,"fip":5.379,"kbb":10.1},{"season":"2024","playerId":65665,"fip":5.03,"kbb":11.9},{"season":"2024","playerId":53996,"fip":5.592,"kbb":6.6},{"season":"2024","playerId":69108,"fip":5.01,"kbb":5.2},{"season":"2024","playerId":53455,"fip":6.909,"kbb":0.9},{"season":"2024","playerId":62754,"fip":5.504,"kbb":9.2},{"season":"2024","playerId":54900,"fip":6.117,"kbb":-1.1},{"season":"2024","playerId":63959,"fip":4.087,"kbb":9.9},{"season":"2024","playerId":61101,"fip":3.851,"kbb":16.5},{"season":"2024","playerId":78352,"fip":4.46,"kbb":8.7},{"season":"2024","playerId":79764,"fip":4.239,"kbb":7.2},{"season":"2024","playerId":77318,"fip":5.247,"kbb":3.8},{"season":"2024","playerId":51895,"fip":6.124,"kbb":0.0},{"season":"2024","playerId":63950,"fip":4.43,"kbb":13.0},{"season":"2024","playerId":54561,"fip":4.994,"kbb":9.7},{"season":"2024","playerId":69969,"fip":6.433,"kbb":0.0},{"season":"2024","playerId":66609,"fip":4.126,"kbb":12.9},{"season":"2024","playerId":54362,"fip":6.976,"kbb":-1.4},{"season":"2024","playerId":69159,"fip":4.437,"kbb":5.6},{"season":"2024","playerId":68242,"fip":6.161,"kbb":7.9},{"season":"2024","playerId":50662,"fip":4.654,"kbb":17.1},{"season":"2024","playerId":54537,"fip":3.349,"kbb":12.5},{"season":"2024","playerId":54768,"fip":5.175,"kbb":9.1},{"season":"2024","playerId":51897,"fip":3.714,"kbb":22.5},{"season":"2024","playerId":63342,"fip":3.964,"kbb":9.9},{"season":"2024","playerId":69360,"fip":6.331,"kbb":3.6},{"season":"2024","playerId":64768,"fip":6.412,"kbb":5.4},{"season":"2024","playerId":65060,"fip":4.911,"kbb":7.9},{"season":"2024","playerId":52330,"fip":4.074,"kbb":13.3},{"season":"2024","playerId":65707,"fip":3.911,"kbb":21.0},{"season":"2024","playerId":76650,"fip":5.747,"kbb":10.2},{"season":"2024","playerId":79140,"fip":6.005,"kbb":4.8},{"season":"2024","playerId":68856,"fip":6.611,"kbb":8.4},{"season":"2024","playerId":66920,"fip":5.487,"kbb":5.5},{"season":"2024","playerId":51264,"fip":5.798,"kbb":11.3},{"season":"2024","playerId":67263,"fip":6.032,"kbb":8.0},{"season":"2024","playerId":65320,"fip":4.555,"kbb":8.3},{"season":"2024","playerId":68036,"fip":5.835,"kbb":1.6},{"season":"2024","playerId":50556,"fip":5.718,"kbb":-1.0},{"season":"2024","playerId":53259,"fip":5.47,"kbb":8.9},{"season":"2024","playerId":52206,"fip":5.127,"kbb":10.4},{"season":"2024","playerId":67421,"fip":3.852,"kbb":12.3},{"season":"2024","playerId":68419,"fip":6.687,"kbb":2.1},{"season":"2024","playerId":52639,"fip":5.513,"kbb":-1.3},{"season":"2024","playerId":68501,"fip":5.249,"kbb":1.4},{"season":"2024","playerId":54920,"fip":4.233,"kbb":13.4},{"season":"2024","playerId":69103,"fip":4.778,"kbb":8.9},{"season":"2024","playerId":54452,"fip":4.524,"kbb":17.8},{"season":"2024","playerId":69032,"fip":4.258,"kbb":13.4},{"season":"2024","playerId":54612,"fip":3.092,"kbb":18.6},{"season":"2024","playerId":52720,"fip":5.83,"kbb":5.3},{"season":"2024","playerId":64350,"fip":4.292,"kbb":6.4},{"season":"2024","playerId":54930,"fip":3.215,"kbb":22.8},{"season":"2024","playerId":68092,"fip":3.67,"kbb":14.3},{"season":"2024","playerId":50726,"fip":5.369,"kbb":3.3},{"season":"2024","playerId":61666,"fip":4.07,"kbb":9.7},{"season":"2024","playerId":51994,"fip":4.304,"kbb":8.5},{"season":"2024","playerId":62363,"fip":4.342,"kbb":13.7},{"season":"2024","playerId":54354,"fip":4.276,"kbb":18.5},{"season":"2024","playerId":61643,"fip":4.985,"kbb":6.1},{"season":"2024","playerId":50441,"fip":4.449,"kbb":6.7},{"season":"2024","playerId":52641,"fip":5.264,"kbb":8.0},{"season":"2024","playerId":54729,"fip":5.701,"kbb":5.6},{"season":"2024","playerId":53375,"fip":3.855,"kbb":17.6},{"season":"2025","playerId":55460,"fip":3.864,"kbb":14.7},{"season":"2025","playerId":55532,"fip":3.432,"kbb":14.3},{"season":"2025","playerId":64001,"fip":3.1,"kbb":18.4},{"season":"2025","playerId":72523,"fip":6.071,"kbb":5.8},{"season":"2025","playerId":68220,"fip":3.697,"kbb":14.2},{"season":"2025","playerId":65522,"fip":5.196,"kbb":4.9},{"season":"2025","playerId":76225,"fip":6.6,"kbb":6.5},{"season":"2025","playerId":51867,"fip":4.238,"kbb":6.6},{"season":"2025","playerId":77829,"fip":3.766,"kbb":14.0},{"season":"2025","playerId":69620,"fip":3.585,"kbb":14.5},{"season":"2025","playerId":52995,"fip":6.347,"kbb":-3.1},{"season":"2025","playerId":54401,"fip":5.738,"kbb":3.8},{"season":"2025","playerId":69745,"fip":4.442,"kbb":6.8},{"season":"2025","playerId":68043,"fip":3.782,"kbb":18.8},{"season":"2025","playerId":65048,"fip":4.126,"kbb":9.6},{"season":"2025","playerId":65769,"fip":3.259,"kbb":10.3},{"season":"2025","playerId":53754,"fip":3.677,"kbb":15.4},{"season":"2025","playerId":66018,"fip":5.494,"kbb":-0.8},{"season":"2025","playerId":67828,"fip":4.525,"kbb":5.3},{"season":"2025","playerId":68928,"fip":6.599,"kbb":7.6},{"season":"2025","playerId":54368,"fip":6.521,"kbb":2.0},{"season":"2025","playerId":68900,"fip":3.859,"kbb":11.1},{"season":"2025","playerId":55167,"fip":3.521,"kbb":11.0},{"season":"2025","playerId":62528,"fip":3.421,"kbb":15.4},{"season":"2025","playerId":54319,"fip":6.155,"kbb":2.1},{"season":"2025","playerId":64580,"fip":7.143,"kbb":0.9},{"season":"2025","playerId":65062,"fip":4.74,"kbb":13.6},{"season":"2025","playerId":68830,"fip":4.5,"kbb":3.9},{"season":"2025","playerId":63765,"fip":4.41,"kbb":8.5},{"season":"2025","playerId":75867,"fip":3.886,"kbb":13.7},{"season":"2025","playerId":51516,"fip":8.442,"kbb":5.9},{"season":"2025","playerId":67954,"fip":4.566,"kbb":8.2},{"season":"2025","playerId":76430,"fip":4.905,"kbb":6.1},{"season":"2025","playerId":55610,"fip":5.94,"kbb":6.5},{"season":"2025","playerId":62360,"fip":3.872,"kbb":17.8},{"season":"2025","playerId":54263,"fip":3.736,"kbb":17.8},{"season":"2025","playerId":65343,"fip":3.89,"kbb":4.2},{"season":"2025","playerId":67539,"fip":4.147,"kbb":11.0},{"season":"2025","playerId":54640,"fip":3.052,"kbb":16.7},{"season":"2025","playerId":73211,"fip":2.892,"kbb":15.0},{"season":"2025","playerId":55536,"fip":3.818,"kbb":13.4},{"season":"2025","playerId":55903,"fip":3.282,"kbb":22.6},{"season":"2025","playerId":54443,"fip":4.205,"kbb":10.7},{"season":"2025","playerId":55912,"fip":4.318,"kbb":11.0},{"season":"2025","playerId":55322,"fip":3.298,"kbb":17.2},{"season":"2025","playerId":65949,"fip":4.268,"kbb":11.6},{"season":"2025","playerId":76715,"fip":3.354,"kbb":17.2},{"season":"2025","playerId":55342,"fip":3.62,"kbb":16.2},{"season":"2025","playerId":53973,"fip":5.577,"kbb":1.4},{"season":"2025","playerId":52701,"fip":2.768,"kbb":20.8},{"season":"2025","playerId":62869,"fip":5.446,"kbb":5.1},{"season":"2025","playerId":67419,"fip":4.486,"kbb":10.7},{"season":"2025","playerId":54802,"fip":6.321,"kbb":1.8},{"season":"2025","playerId":53139,"fip":5.008,"kbb":9.5},{"season":"2025","playerId":67703,"fip":3.93,"kbb":10.5},{"season":"2025","playerId":64021,"fip":3.834,"kbb":14.1},{"season":"2025","playerId":50812,"fip":5.239,"kbb":2.6},{"season":"2025","playerId":68249,"fip":4.255,"kbb":4.9},{"season":"2025","playerId":52060,"fip":4.26,"kbb":15.4},{"season":"2025","playerId":53301,"fip":5.282,"kbb":9.3},{"season":"2025","playerId":65639,"fip":4.012,"kbb":6.7},{"season":"2025","playerId":55394,"fip":6.492,"kbb":-11.2},{"season":"2025","playerId":69328,"fip":5.751,"kbb":4.3},{"season":"2025","playerId":69594,"fip":4.832,"kbb":9.3},{"season":"2025","playerId":67266,"fip":3.709,"kbb":13.7},{"season":"2025","playerId":52528,"fip":4.127,"kbb":10.3},{"season":"2025","playerId":64995,"fip":4.548,"kbb":6.6},{"season":"2025","playerId":65516,"fip":3.775,"kbb":10.2},{"season":"2025","playerId":55455,"fip":3.997,"kbb":10.3},{"season":"2025","playerId":65109,"fip":5.271,"kbb":0.0},{"season":"2025","playerId":77446,"fip":2.724,"kbb":18.8},{"season":"2025","playerId":55526,"fip":6.205,"kbb":6.0},{"season":"2025","playerId":54610,"fip":3.5,"kbb":8.6},{"season":"2025","playerId":50030,"fip":2.896,"kbb":15.4},{"season":"2025","playerId":69041,"fip":3.473,"kbb":17.9},{"season":"2025","playerId":67143,"fip":3.398,"kbb":12.9},{"season":"2025","playerId":54904,"fip":4.392,"kbb":8.0},{"season":"2025","playerId":51111,"fip":4.064,"kbb":12.1},{"season":"2025","playerId":53898,"fip":5.757,"kbb":3.5},{"season":"2025","playerId":51594,"fip":5.442,"kbb":3.3},{"season":"2025","playerId":68902,"fip":5.102,"kbb":10.4},{"season":"2025","playerId":69045,"fip":3.413,"kbb":16.7},{"season":"2025","playerId":54833,"fip":2.566,"kbb":28.1},{"season":"2025","playerId":55215,"fip":4.476,"kbb":11.8},{"season":"2025","playerId":68415,"fip":3.881,"kbb":9.8},{"season":"2025","playerId":77637,"fip":4.176,"kbb":7.8},{"season":"2025","playerId":65056,"fip":5.376,"kbb":9.5},{"season":"2025","playerId":54119,"fip":3.889,"kbb":17.8},{"season":"2025","playerId":67116,"fip":4.639,"kbb":6.0},{"season":"2025","playerId":50859,"fip":3.926,"kbb":11.0},{"season":"2025","playerId":55633,"fip":2.942,"kbb":19.7},{"season":"2025","playerId":54755,"fip":3.192,"kbb":20.8},{"season":"2025","playerId":73117,"fip":3.314,"kbb":11.9},{"season":"2025","playerId":54063,"fip":5.387,"kbb":5.0},{"season":"2025","playerId":76118,"fip":4.178,"kbb":9.7},{"season":"2025","playerId":69446,"fip":4.245,"kbb":12.2},{"season":"2025","playerId":55348,"fip":2.855,"kbb":11.8},{"season":"2025","playerId":50106,"fip":3.185,"kbb":18.1},{"season":"2025","playerId":54404,"fip":6.405,"kbb":-3.8},{"season":"2025","playerId":52395,"fip":3.967,"kbb":10.6},{"season":"2025","playerId":67588,"fip":4.145,"kbb":19.2},{"season":"2025","playerId":53613,"fip":4.585,"kbb":5.7},{"season":"2025","playerId":55396,"fip":7.041,"kbb":-6.4},{"season":"2025","playerId":50036,"fip":5.188,"kbb":7.6},{"season":"2025","playerId":53892,"fip":3.69,"kbb":14.8},{"season":"2025","playerId":52530,"fip":5.489,"kbb":1.2},{"season":"2025","playerId":69054,"fip":3.728,"kbb":15.5},{"season":"2025","playerId":50464,"fip":4.026,"kbb":10.4},{"season":"2025","playerId":60146,"fip":5.984,"kbb":11.8},{"season":"2025","playerId":51454,"fip":4.855,"kbb":5.9},{"season":"2025","playerId":66291,"fip":3.96,"kbb":11.7},{"season":"2025","playerId":51648,"fip":5.825,"kbb":5.7},{"season":"2025","playerId":69134,"fip":4.258,"kbb":10.1},{"season":"2025","playerId":65665,"fip":4.581,"kbb":17.2},{"season":"2025","playerId":55301,"fip":6.579,"kbb":8.5},{"season":"2025","playerId":52992,"fip":6.54,"kbb":7.1},{"season":"2025","playerId":69108,"fip":4.44,"kbb":7.1},{"season":"2025","playerId":53455,"fip":4.236,"kbb":15.9},{"season":"2025","playerId":61101,"fip":3.642,"kbb":10.1},{"season":"2025","playerId":63950,"fip":4.431,"kbb":7.7},{"season":"2025","playerId":55239,"fip":3.177,"kbb":16.2},{"season":"2025","playerId":69969,"fip":3.83,"kbb":8.9},{"season":"2025","playerId":66609,"fip":3.533,"kbb":11.4},{"season":"2025","playerId":52809,"fip":4.259,"kbb":13.2},{"season":"2025","playerId":54362,"fip":6.011,"kbb":-0.9},{"season":"2025","playerId":55743,"fip":3.535,"kbb":26.8},{"season":"2025","playerId":68242,"fip":3.99,"kbb":9.3},{"season":"2025","playerId":50662,"fip":2.886,"kbb":20.0},{"season":"2025","playerId":54537,"fip":4.286,"kbb":10.3},{"season":"2025","playerId":55313,"fip":5.323,"kbb":1.8},{"season":"2025","playerId":54768,"fip":4.338,"kbb":6.0},{"season":"2025","playerId":51897,"fip":2.736,"kbb":24.7},{"season":"2025","playerId":63342,"fip":4.155,"kbb":11.4},{"season":"2025","playerId":69360,"fip":5.825,"kbb":2.5},{"season":"2025","playerId":65060,"fip":4.314,"kbb":4.0},{"season":"2025","playerId":52330,"fip":5.177,"kbb":10.1},{"season":"2025","playerId":65707,"fip":5.061,"kbb":14.0},{"season":"2025","playerId":55268,"fip":4.679,"kbb":6.0},{"season":"2025","playerId":68856,"fip":4.486,"kbb":7.0},{"season":"2025","playerId":66920,"fip":5.544,"kbb":2.6},{"season":"2025","playerId":51264,"fip":4.161,"kbb":6.9},{"season":"2025","playerId":67263,"fip":5.554,"kbb":5.7},{"season":"2025","playerId":65320,"fip":4.506,"kbb":10.7},{"season":"2025","playerId":50556,"fip":3.533,"kbb":19.7},{"season":"2025","playerId":52206,"fip":3.558,"kbb":17.4},{"season":"2025","playerId":68419,"fip":4.853,"kbb":5.3},{"season":"2025","playerId":52639,"fip":6.255,"kbb":-4.7},{"season":"2025","playerId":55146,"fip":2.987,"kbb":13.7},{"season":"2025","playerId":55138,"fip":6.144,"kbb":3.7},{"season":"2025","playerId":55257,"fip":4.435,"kbb":7.7},{"season":"2025","playerId":69032,"fip":5.459,"kbb":3.1},{"season":"2025","playerId":55130,"fip":3.109,"kbb":16.3},{"season":"2025","playerId":55032,"fip":3.487,"kbb":9.0},{"season":"2025","playerId":55730,"fip":2.115,"kbb":30.3},{"season":"2025","playerId":64350,"fip":3.718,"kbb":14.1},{"season":"2025","playerId":68092,"fip":3.845,"kbb":5.3},{"season":"2025","playerId":61666,"fip":3.92,"kbb":11.5},{"season":"2025","playerId":51994,"fip":6.135,"kbb":2.5},{"season":"2025","playerId":63248,"fip":3.96,"kbb":7.1},{"season":"2025","playerId":54354,"fip":3.692,"kbb":17.0},{"season":"2025","playerId":55267,"fip":5.385,"kbb":1.3},{"season":"2025","playerId":50596,"fip":2.186,"kbb":21.7},{"season":"2025","playerId":55855,"fip":3.375,"kbb":16.7},{"season":"2025","playerId":50441,"fip":4.227,"kbb":7.7},{"season":"2025","playerId":52641,"fip":4.218,"kbb":13.5},{"season":"2025","playerId":54729,"fip":4.387,"kbb":13.6},{"season":"2025","playerId":53375,"fip":3.693,"kbb":13.5},{"season":"2026","playerId":56769,"fip":6.989,"kbb":2.4},{"season":"2026","playerId":50705,"fip":4.574,"kbb":8.3},{"season":"2026","playerId":64001,"fip":3.207,"kbb":22.8},{"season":"2026","playerId":67119,"fip":2.461,"kbb":24.7},{"season":"2026","playerId":53609,"fip":3.705,"kbb":16.3},{"season":"2026","playerId":68220,"fip":2.809,"kbb":24.4},{"season":"2026","playerId":65933,"fip":4.487,"kbb":12.3},{"season":"2026","playerId":55764,"fip":4.729,"kbb":6.4},{"season":"2026","playerId":65522,"fip":4.73,"kbb":-1.0},{"season":"2026","playerId":51867,"fip":5.915,"kbb":7.2},{"season":"2026","playerId":68043,"fip":3.175,"kbb":15.6},{"season":"2026","playerId":65048,"fip":4.439,"kbb":11.9},{"season":"2026","playerId":56840,"fip":4.372,"kbb":10.1},{"season":"2026","playerId":65769,"fip":5.023,"kbb":4.1},{"season":"2026","playerId":53754,"fip":7.048,"kbb":-0.7},{"season":"2026","playerId":66018,"fip":6.308,"kbb":0.0},{"season":"2026","playerId":51301,"fip":4.689,"kbb":7.0},{"season":"2026","playerId":68900,"fip":5.29,"kbb":3.8},{"season":"2026","playerId":55167,"fip":3.901,"kbb":9.9},{"season":"2026","playerId":62528,"fip":4.196,"kbb":9.8},{"season":"2026","playerId":50157,"fip":5.954,"kbb":-4.2},{"season":"2026","playerId":54319,"fip":7.741,"kbb":2.2},{"season":"2026","playerId":67391,"fip":6.745,"kbb":-2.1},{"season":"2026","playerId":65062,"fip":3.657,"kbb":16.1},{"season":"2026","playerId":68830,"fip":4.374,"kbb":8.1},{"season":"2026","playerId":53029,"fip":4.548,"kbb":11.4},{"season":"2026","playerId":63765,"fip":6.903,"kbb":1.1},{"season":"2026","playerId":75867,"fip":4.858,"kbb":8.8},{"season":"2026","playerId":51154,"fip":5.024,"kbb":5.6},{"season":"2026","playerId":51516,"fip":4.691,"kbb":11.5},{"season":"2026","playerId":67954,"fip":6.901,"kbb":-5.3},{"season":"2026","playerId":50992,"fip":5.666,"kbb":6.3},{"season":"2026","playerId":55610,"fip":5.552,"kbb":4.7},{"season":"2026","playerId":62360,"fip":4.473,"kbb":10.8},{"season":"2026","playerId":54263,"fip":4.219,"kbb":18.8},{"season":"2026","playerId":67539,"fip":4.39,"kbb":13.2},{"season":"2026","playerId":54640,"fip":3.652,"kbb":15.7},{"season":"2026","playerId":73211,"fip":6.171,"kbb":9.6},{"season":"2026","playerId":56002,"fip":2.603,"kbb":22.4},{"season":"2026","playerId":55903,"fip":3.638,"kbb":24.2},{"season":"2026","playerId":55912,"fip":4.271,"kbb":14.1},{"season":"2026","playerId":56531,"fip":4.331,"kbb":18.7},{"season":"2026","playerId":55322,"fip":3.582,"kbb":16.1},{"season":"2026","playerId":65949,"fip":6.673,"kbb":6.9},{"season":"2026","playerId":76715,"fip":3.363,"kbb":17.1},{"season":"2026","playerId":52701,"fip":5.398,"kbb":6.4},{"season":"2026","playerId":62869,"fip":5.272,"kbb":3.2},{"season":"2026","playerId":56415,"fip":6.646,"kbb":4.9},{"season":"2026","playerId":67703,"fip":3.706,"kbb":15.6},{"season":"2026","playerId":64021,"fip":4.247,"kbb":11.1},{"season":"2026","playerId":55121,"fip":3.767,"kbb":10.5},{"season":"2026","playerId":50812,"fip":6.098,"kbb":7.0},{"season":"2026","playerId":68249,"fip":5.586,"kbb":8.6},{"season":"2026","playerId":52060,"fip":4.035,"kbb":16.0},{"season":"2026","playerId":56536,"fip":4.447,"kbb":11.7},{"season":"2026","playerId":55394,"fip":4.851,"kbb":3.6},{"season":"2026","playerId":52731,"fip":5.889,"kbb":7.0},{"season":"2026","playerId":56709,"fip":7.328,"kbb":5.4},{"season":"2026","playerId":56318,"fip":4.986,"kbb":3.4},{"season":"2026","playerId":56337,"fip":6.229,"kbb":3.3},{"season":"2026","playerId":63512,"fip":4.352,"kbb":7.2},{"season":"2026","playerId":67266,"fip":4.003,"kbb":13.7},{"season":"2026","playerId":51761,"fip":4.161,"kbb":11.3},{"season":"2026","playerId":63145,"fip":6.292,"kbb":2.2},{"season":"2026","playerId":64995,"fip":4.339,"kbb":11.9},{"season":"2026","playerId":65516,"fip":4.12,"kbb":8.0},{"season":"2026","playerId":55455,"fip":5.685,"kbb":3.9},{"season":"2026","playerId":77446,"fip":6.994,"kbb":2.8},{"season":"2026","playerId":56928,"fip":4.108,"kbb":11.9},{"season":"2026","playerId":56841,"fip":5.67,"kbb":9.7},{"season":"2026","playerId":52043,"fip":2.938,"kbb":19.1},{"season":"2026","playerId":56036,"fip":3.149,"kbb":15.3},{"season":"2026","playerId":56402,"fip":2.748,"kbb":22.4},{"season":"2026","playerId":56523,"fip":3.718,"kbb":17.4},{"season":"2026","playerId":56032,"fip":4.989,"kbb":5.9},{"season":"2026","playerId":54610,"fip":4.092,"kbb":10.7},{"season":"2026","playerId":50030,"fip":3.541,"kbb":15.4},{"season":"2026","playerId":69041,"fip":4.723,"kbb":11.8},{"season":"2026","playerId":67143,"fip":4.164,"kbb":8.4},{"season":"2026","playerId":54904,"fip":4.816,"kbb":9.8},{"season":"2026","playerId":69962,"fip":6.626,"kbb":10.9},{"season":"2026","playerId":51111,"fip":5.034,"kbb":9.7},{"season":"2026","playerId":56011,"fip":4.33,"kbb":13.3},{"season":"2026","playerId":54843,"fip":5.024,"kbb":6.6},{"season":"2026","playerId":68902,"fip":6.044,"kbb":3.3},{"season":"2026","playerId":53919,"fip":5.394,"kbb":4.0},{"season":"2026","playerId":56801,"fip":2.662,"kbb":18.1},{"season":"2026","playerId":68341,"fip":3.325,"kbb":19.3},{"season":"2026","playerId":69045,"fip":3.857,"kbb":18.6},{"season":"2026","playerId":55215,"fip":4.576,"kbb":16.4},{"season":"2026","playerId":68415,"fip":4.851,"kbb":9.1},{"season":"2026","playerId":77637,"fip":5.217,"kbb":4.9},{"season":"2026","playerId":56712,"fip":4.95,"kbb":6.5},{"season":"2026","playerId":56464,"fip":4.424,"kbb":11.7},{"season":"2026","playerId":67116,"fip":4.683,"kbb":0.0},{"season":"2026","playerId":50859,"fip":3.978,"kbb":14.1},{"season":"2026","playerId":55633,"fip":3.728,"kbb":16.5},{"season":"2026","playerId":56334,"fip":4.148,"kbb":12.8},{"season":"2026","playerId":56719,"fip":4.872,"kbb":7.1},{"season":"2026","playerId":51526,"fip":4.612,"kbb":10.4},{"season":"2026","playerId":73117,"fip":4.639,"kbb":7.6},{"season":"2026","playerId":54906,"fip":6.105,"kbb":0.0},{"season":"2026","playerId":76118,"fip":3.902,"kbb":9.1},{"season":"2026","playerId":69446,"fip":3.342,"kbb":13.1},{"season":"2026","playerId":55348,"fip":4.576,"kbb":12.9},{"season":"2026","playerId":56348,"fip":3.965,"kbb":16.4},{"season":"2026","playerId":69213,"fip":5.776,"kbb":3.0},{"season":"2026","playerId":52202,"fip":3.913,"kbb":8.1},{"season":"2026","playerId":64861,"fip":4.331,"kbb":10.1},{"season":"2026","playerId":53892,"fip":4.128,"kbb":13.4},{"season":"2026","playerId":52530,"fip":5.039,"kbb":2.9},{"season":"2026","playerId":65616,"fip":4.829,"kbb":3.0},{"season":"2026","playerId":52204,"fip":4.914,"kbb":7.8},{"season":"2026","playerId":65117,"fip":4.582,"kbb":7.4},{"season":"2026","playerId":69054,"fip":6.633,"kbb":7.9},{"season":"2026","playerId":50464,"fip":3.975,"kbb":10.2},{"season":"2026","playerId":60146,"fip":4.794,"kbb":8.5},{"season":"2026","playerId":51454,"fip":4.757,"kbb":11.3},{"season":"2026","playerId":66291,"fip":3.151,"kbb":19.0},{"season":"2026","playerId":51948,"fip":3.894,"kbb":3.4},{"season":"2026","playerId":77211,"fip":5.726,"kbb":17.3},{"season":"2026","playerId":61145,"fip":3.804,"kbb":9.3},{"season":"2026","playerId":51648,"fip":6.043,"kbb":4.2},{"season":"2026","playerId":56503,"fip":3.605,"kbb":14.6},{"season":"2026","playerId":69134,"fip":5.137,"kbb":0.0},{"season":"2026","playerId":52992,"fip":4.193,"kbb":8.3},{"season":"2026","playerId":53562,"fip":3.679,"kbb":9.1},{"season":"2026","playerId":60768,"fip":3.633,"kbb":11.7},{"season":"2026","playerId":62951,"fip":5.361,"kbb":5.6},{"season":"2026","playerId":62754,"fip":4.689,"kbb":11.8},{"season":"2026","playerId":52902,"fip":5.177,"kbb":12.5},{"season":"2026","playerId":61101,"fip":4.261,"kbb":8.4},{"season":"2026","playerId":69645,"fip":5.004,"kbb":7.8},{"season":"2026","playerId":56460,"fip":5.667,"kbb":8.9},{"season":"2026","playerId":63950,"fip":4.256,"kbb":10.0},{"season":"2026","playerId":55239,"fip":4.298,"kbb":15.3},{"season":"2026","playerId":69969,"fip":5.12,"kbb":4.4},{"season":"2026","playerId":66609,"fip":3.678,"kbb":17.6},{"season":"2026","playerId":52809,"fip":5.984,"kbb":13.7},{"season":"2026","playerId":69047,"fip":4.166,"kbb":6.8},{"season":"2026","playerId":54362,"fip":5.994,"kbb":-2.9},{"season":"2026","playerId":56345,"fip":7.155,"kbb":-2.9},{"season":"2026","playerId":55743,"fip":6.048,"kbb":7.5},{"season":"2026","playerId":68242,"fip":5.048,"kbb":5.5},{"season":"2026","playerId":50662,"fip":4.668,"kbb":12.6},{"season":"2026","playerId":55313,"fip":7.598,"kbb":0.0},{"season":"2026","playerId":54768,"fip":4.116,"kbb":13.8},{"season":"2026","playerId":51897,"fip":3.789,"kbb":18.4},{"season":"2026","playerId":63342,"fip":4.405,"kbb":7.6},{"season":"2026","playerId":69360,"fip":5.239,"kbb":11.5},{"season":"2026","playerId":65060,"fip":4.945,"kbb":3.1},{"season":"2026","playerId":65707,"fip":6.244,"kbb":9.9},{"season":"2026","playerId":56799,"fip":5.727,"kbb":11.5},{"season":"2026","playerId":55268,"fip":3.746,"kbb":11.9},{"season":"2026","playerId":68856,"fip":5.633,"kbb":5.3},{"season":"2026","playerId":51264,"fip":5.136,"kbb":7.0},{"season":"2026","playerId":65320,"fip":4.3,"kbb":13.7},{"season":"2026","playerId":50556,"fip":3.96,"kbb":13.5},{"season":"2026","playerId":53259,"fip":5.331,"kbb":12.5},{"season":"2026","playerId":67421,"fip":2.866,"kbb":15.6},{"season":"2026","playerId":52639,"fip":6.139,"kbb":9.3},{"season":"2026","playerId":55146,"fip":5.033,"kbb":8.5},{"season":"2026","playerId":56103,"fip":3.332,"kbb":16.1},{"season":"2026","playerId":56168,"fip":3.675,"kbb":16.2},{"season":"2026","playerId":56760,"fip":3.79,"kbb":22.7},{"season":"2026","playerId":56939,"fip":6.133,"kbb":5.9},{"season":"2026","playerId":56212,"fip":4.186,"kbb":9.8},{"season":"2026","playerId":56823,"fip":5.074,"kbb":6.6},{"season":"2026","playerId":56966,"fip":4.61,"kbb":8.5},{"season":"2026","playerId":56911,"fip":5.072,"kbb":8.6},{"season":"2026","playerId":55130,"fip":4.124,"kbb":12.9},{"season":"2026","playerId":56459,"fip":3.024,"kbb":22.8},{"season":"2026","playerId":64350,"fip":3.989,"kbb":11.8},{"season":"2026","playerId":68092,"fip":4.143,"kbb":9.5},{"season":"2026","playerId":61666,"fip":4.816,"kbb":10.2},{"season":"2026","playerId":51994,"fip":5.644,"kbb":2.2},{"season":"2026","playerId":63248,"fip":5.423,"kbb":4.9},{"season":"2026","playerId":56855,"fip":4.218,"kbb":12.2},{"season":"2026","playerId":68260,"fip":4.433,"kbb":5.3},{"season":"2026","playerId":55267,"fip":4.486,"kbb":7.8},{"season":"2026","playerId":55855,"fip":3.744,"kbb":9.9},{"season":"2026","playerId":56724,"fip":3.947,"kbb":10.8},{"season":"2026","playerId":52641,"fip":6.075,"kbb":6.8},{"season":"2026","playerId":54729,"fip":5.527,"kbb":7.3},{"season":"2026","playerId":53375,"fip":4.328,"kbb":10.5}];

(function () {
  const ADVANCED_MAP = new Map(SIX_AXIS_PITCHER_ADVANCED.map(x => [`${x.season}|${x.playerId}`, x]));
  const HITTER_METRICS = [
    { key: 'ops', label: 'OPS', higher: true, raw: p => numeric(p.OPS) },
    { key: 'avg', label: '타율', higher: true, raw: p => numeric(p.AVG) },
    { key: 'obp', label: '출루율', higher: true, raw: p => numeric(p.OBP) },
    { key: 'wrcPlus', label: 'wRC+', higher: true, raw: p => numeric(p['wRC+']) },
    { key: 'hits', label: '안타 수', higher: true, raw: p => numeric(p.H) },
    { key: 'defense', label: '수비', higher: true, raw: p => numeric(p.defIdx), positionSpecific: true }
  ];
  const PITCHER_METRICS = [
    { key: 'ip', label: '이닝', higher: true, raw: p => numeric(p.IP_decimal) },
    { key: 'so', label: '삼진', higher: true, raw: p => numeric(p.SO) },
    { key: 'era', label: 'ERA', higher: false, raw: p => numeric(p.ERA) },
    { key: 'fip', label: 'FIP', higher: false, raw: (p, season) => advancedValue(p, season, 'fip') },
    { key: 'kbb', label: 'K-BB%', higher: true, raw: (p, season) => advancedValue(p, season, 'kbb') },
    { key: 'whip', label: 'WHIP', higher: false, raw: p => numeric(p.WHIP) }
  ];
  const RELIEVER_METRICS = [
    { key: 'g', label: '등판', higher: true, raw: p => numeric(p.G) },
    ...PITCHER_METRICS.slice(1)
  ];
  const cache = new Map();

  function pitcherRole(p) {
    if (p.pos === 'SP' || p.pos === 'RP') return p.pos;
    const g = numeric(p.G), gs = numeric(p.GS);
    return g && gs !== null && gs / g >= 0.5 ? 'SP' : 'RP';
  }
  function groupType(player, type) {
    return type === 'pitcher' ? `pitcher-${pitcherRole(player)}` : type;
  }
  function numeric(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  function advancedValue(player, season, key) {
    const item = ADVANCED_MAP.get(`${season}|${player['선수ID']}`);
    return item ? numeric(item[key]) : null;
  }
  function allPlayers(season, type) {
    const seasonData = typeof kboCompleteDatabase !== "undefined" && kboCompleteDatabase[String(season)];
    if (!seasonData) return [];
    const prop = type.startsWith('pitcher') ? 'pitchers' : 'hitters';
    const list = Object.values(seasonData).flatMap(team => team[prop] || []);
    if (type === 'pitcher-SP') return list.filter(p => pitcherRole(p) === 'SP');
    if (type === 'pitcher-RP') return list.filter(p => pitcherRole(p) === 'RP');
    return list;
  }
  function percentileScores(entries, higher) {
    const valid = entries.filter(x => x.value !== null).sort((a, b) => a.value - b.value);
    const scores = new Map();
    if (!valid.length) return scores;
    if (valid.length === 1) {
      scores.set(String(valid[0].player['선수ID']), 50);
      return scores;
    }
    let i = 0;
    while (i < valid.length) {
      let j = i;
      while (j + 1 < valid.length && valid[j + 1].value === valid[i].value) j++;
      const averageRank = (i + j) / 2;
      let score = averageRank / (valid.length - 1) * 100;
      if (!higher) score = 100 - score;
      for (let k = i; k <= j; k++) scores.set(String(valid[k].player['선수ID']), score);
      i = j + 1;
    }
    return scores;
  }
  function seasonMetricScores(season, type, metric) {
    const cacheKey = `${season}|${type}|${metric.key}`;
    if (cache.has(cacheKey)) return cache.get(cacheKey);
    const players = allPlayers(season, type);
    const values = players.map(player => ({
      player,
      value: metric.raw(player, season),
      position: metric.positionSpecific ? (player.mainPos && (player.mainPos['포지션코드'] || player.mainPos.POS)) : null
    }));
    let scores;
    if (metric.positionSpecific) {
      scores = new Map();
      const positions = [...new Set(values.filter(x => x.value !== null && x.position).map(x => x.position))];
      positions.forEach(position => {
        const group = values.filter(x => x.position === position && x.value !== null);
        const part = percentileScores(group, metric.higher);
        part.forEach((v, k) => scores.set(k, v));
      });
    } else {
      scores = percentileScores(values, metric.higher);
    }
    cache.set(cacheKey, scores);
    return scores;
  }
  function formatRaw(metricKey, value, player, season) {
    if (value === null) return '자료 없음';
    if (metricKey === 'ops' || metricKey === 'avg' || metricKey === 'obp') return value.toFixed(3);
    if (metricKey === 'wrcPlus' || metricKey === 'hits' || metricKey === 'so' || metricKey === 'g') return String(Math.round(value));
    if (metricKey === 'defense') return `${value.toFixed(1)}${player.mainPos && player.mainPos.POS ? ` (${player.mainPos.POS})` : ''}`;
    if (metricKey === 'ip') return player.IP || value.toFixed(1);
    if (metricKey === 'era' || metricKey === 'fip' || metricKey === 'whip') return value.toFixed(2);
    if (metricKey === 'kbb') return `${value.toFixed(1)}%`;
    return String(value);
  }
  function getPlayerMetrics(player, season, type) {
    const gType = groupType(player, type);
    const metrics = gType === 'pitcher-RP' ? RELIEVER_METRICS : (gType === 'pitcher-SP' ? PITCHER_METRICS : HITTER_METRICS);
    return metrics.map(metric => {
      const raw = metric.raw(player, String(season));
      const scores = seasonMetricScores(String(season), gType, metric);
      const score = raw === null ? null : (scores.has(String(player['선수ID'])) ? scores.get(String(player['선수ID'])) : null);
      return { key: metric.key, label: metric.label, raw, rawText: formatRaw(metric.key, raw, player, String(season)), score: score === null ? null : Math.round(score * 10) / 10 };
    });
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  // 겹쳐서 그리는 레이더 SVG 생성 (결측값 유연 대응)
  function radarSvg(metrics1, metrics2) {
    const width = 520, height = 450, cx = 260, cy = 215, radius = 142;
    const angle = i => -Math.PI / 2 + i * Math.PI * 2 / 6;
    const point = (i, r) => [cx + Math.cos(angle(i)) * r, cy + Math.sin(angle(i)) * r];
    let svg = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="6개 지표 레이더 차트 비교" class="w-full max-w-[560px] mx-auto">`;
    
    // 배경 그리드
    [20,40,60,80,100].forEach(level => {
      const pts = metrics1.map((_, i) => point(i, radius * level / 100).join(',')).join(' ');
      svg += `<polygon points="${pts}" fill="none" stroke="#dbe4df" stroke-width="1"/>`;
      svg += `<text x="${cx + 5}" y="${cy - radius * level / 100 + 12}" fill="#94a3b8" font-size="10">${level}</text>`;
    });
    metrics1.forEach((m, i) => {
      const [x, y] = point(i, radius);
      svg += `<line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#cbd5e1" stroke-width="1"/>`;
    });

    // 보조 함수: 결측값이 있어도 존재하는 점들끼리 폴리곤(면)과 선을 그려줌
    function drawPolygonLayer(metrics, fillColor, strokeColor) {
      const pts = metrics.map((m, i) => m.score === null ? null : point(i, radius * m.score / 100));
      const validPts = pts.filter(Boolean);
      if (validPts.length >= 3) {
        svg += `<polygon points="${validPts.map(p => p.join(',')).join(' ')}" fill="${fillColor}" stroke="${strokeColor}" stroke-width="2" stroke-linejoin="round"/>`;
      } else if (validPts.length === 2) {
        svg += `<line x1="${validPts[0][0]}" y1="${validPts[0][1]}" x2="${validPts[1][0]}" y2="${validPts[1][1]}" stroke="${strokeColor}" stroke-width="2" stroke-linecap="round"/>`;
      }
      pts.forEach(p => {
        if (p) svg += `<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="${strokeColor}" stroke="#fff" stroke-width="1.5"/>`;
      });
    }

    // 2번 선수(비교 선수 - 연한 파란색 영역) 먼저 그림
    if (metrics2) {
      drawPolygonLayer(metrics2, "rgba(59,130,246,0.12)", "#3b82f6");
    }

    // 1번 선수(메인 선수 - 진한 초록색 영역) 나중에 얹어서 그림
    drawPolygonLayer(metrics1, "rgba(5,150,105,0.22)", "#047857");

    // 축 라벨 및 점수 텍스트
    metrics1.forEach((m, i) => {
      const [x, y] = point(i, radius + 32);
      const anchor = Math.abs(x - cx) < 14 ? 'middle' : (x < cx ? 'end' : 'start');
      const labelY = y + (y < cy - 130 ? -2 : 4);
      svg += `<text x="${x}" y="${labelY}" text-anchor="${anchor}" fill="#334155" font-size="13" font-weight="700">${escapeHtml(m.label)}</text>`;
      
      if (metrics2) {
        const m2 = metrics2[i];
        const score1Text = m.score === null ? '-' : `${m.score.toFixed(1)}`;
        const score2Text = m2.score === null ? '-' : `${m2.score.toFixed(1)}`;
        svg += `<text x="${x}" y="${labelY + 15}" text-anchor="${anchor}" font-size="9"><tspan fill="#047857" font-weight="700">${score1Text}</tspan> <tspan fill="#94a3b8">|</tspan> <tspan fill="#3b82f6" font-weight="700">${score2Text}</tspan></text>`;
      } else {
        if (m.score === null) svg += `<text x="${x}" y="${labelY + 15}" text-anchor="${anchor}" fill="#9ca3af" font-size="10">자료 없음</text>`;
        else svg += `<text x="${x}" y="${labelY + 15}" text-anchor="${anchor}" fill="#047857" font-size="10" font-weight="700">${m.score.toFixed(1)}점</text>`;
      }
    });
    svg += '</svg>';
    return svg;
  }

  function render(chartTargetId, metricsTargetId, player, season, type, comparePlayer = null) {
    const chartTarget = document.getElementById(chartTargetId);
    const metricsTarget = document.getElementById(metricsTargetId);
    if (!chartTarget || !metricsTarget) return;
    if (!player) {
      chartTarget.innerHTML = '<p class="text-sm text-gray-400 text-center py-16">선수를 선택하면 6각형 지표가 표시됩니다.</p>';
      metricsTarget.innerHTML = '';
      return;
    }
    const metrics1 = getPlayerMetrics(player, String(season), type);
    const metrics2 = comparePlayer ? getPlayerMetrics(comparePlayer, String(season), type) : null;
    
    const gType = groupType(player, type);
    const groupLabel = gType === 'pitcher-SP' ? '선발투수' : gType === 'pitcher-RP' ? '불펜투수' : '타자';
    const groupN = allPlayers(String(season), gType).length;
    
    chartTarget.innerHTML = `<div class="w-full"><p class="text-xs text-gray-500 text-center mb-1">${season} 시즌 <b class="text-emerald-700">${groupLabel} ${groupN}명</b> 중 백분위 (100점 = 1위)</p>${radarSvg(metrics1, metrics2)}</div>`;
    
    // 비교할 때는 한 줄씩(메인|비교), 혼자 볼 때는 원래의 카드 격자
    metricsTarget.className = metrics2 ? "space-y-2.5" : "grid grid-cols-2 md:grid-cols-3 gap-2";
    metricsTarget.innerHTML = metrics1.map((m1, i) => {
      const m2 = metrics2 ? metrics2[i] : null;
      if (m2) {
        return `
          <div class="rounded-lg bg-gray-50 border border-gray-100 p-3 flex items-center justify-between">
            <div class="w-20">
              <div class="text-[11px] font-bold text-gray-500">${escapeHtml(m1.label)}</div>
            </div>
            <div class="flex-1 text-right pr-4 border-r border-gray-200">
              <div class="text-[10px] font-bold text-emerald-800">${escapeHtml(player.name)} (메인)</div>
              <div class="text-sm font-extrabold text-gray-900">${escapeHtml(m1.rawText)}</div>
              <div class="text-[11px] text-emerald-700 font-bold">${m1.score === null ? '-' : `${m1.score.toFixed(1)}점`}</div>
            </div>
            <div class="flex-1 text-left pl-4">
              <div class="text-[10px] font-bold text-blue-600">${escapeHtml(comparePlayer.name)} (비교)</div>
              <div class="text-sm font-extrabold text-gray-900">${escapeHtml(m2.rawText)}</div>
              <div class="text-[11px] text-blue-600 font-bold">${m2.score === null ? '-' : `${m2.score.toFixed(1)}점`}</div>
            </div>
          </div>`;
      } else {
        return `
          <div class="rounded-lg bg-gray-50 border border-gray-100 p-3">
            <div class="text-[11px] font-bold text-gray-500">${escapeHtml(m1.label)}</div>
            <div class="text-lg font-extrabold text-gray-900 mt-1">${escapeHtml(m1.rawText)}</div>
            <div class="text-xs text-emerald-700 font-bold mt-1">${m1.score === null ? '점수 자료 없음' : `${m1.score.toFixed(1)} / 100점`}</div>
          </div>`;
      }
    }).join('');
  }

  window.SixAxis = { getPlayerMetrics, render, pitcherRole, getAdvancedPitcherData: (season, id) => ADVANCED_MAP.get(`${season}|${id}`) || null };
})();